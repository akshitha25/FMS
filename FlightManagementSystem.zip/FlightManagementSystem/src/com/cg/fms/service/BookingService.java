package com.cg.fms.service;

import java.util.List;

import com.cg.fms.dao.BookingDAO;
import com.cg.fms.dao.IBookingDAO;
import com.cg.fms.exceptions.BookingNotFoundException;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;

public class BookingService implements IBookingService{
	
	IBookingDAO bookingDao = new BookingDAO();
	/*********************************************************************
	 @Description : Method to book a flight
	 @author : Sashwat Dubey
	 @arg1 : Booking booking
	 @return : int
	 @Exception : FMSException
	 */

	public int makeBooking(Booking booking) throws FMSException {
		return bookingDao.makeBooking(booking);
	}

	/*********************************************************************
	 @Description : Method to cancel booking made by customer
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean cancelBooking(int bookingId) throws BookingNotFoundException,FMSException {
		return bookingDao.cancelBooking(bookingId);
	}
	
	/*********************************************************************
	 @Description : Method to view all the bookings made by the customer
	 @author : Akshitha Gampa
	 @arg1 : int userId
	 @return : List<Booking>
	 @Exception : FMSException
	 */
	public List<Booking> viewBookings(int userId) throws BookingNotFoundException,FMSException {
		return bookingDao.viewBookings(userId);
	}

	/*********************************************************************
	 @Description : Method to view all booking details after booking is done
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : Booking
	 @Exception :  FMSException 
	 */
	public Booking viewBookingDetails(int bookingId) throws BookingNotFoundException,FMSException {
		return bookingDao.viewBookingDetails(bookingId);
	}

	

}
