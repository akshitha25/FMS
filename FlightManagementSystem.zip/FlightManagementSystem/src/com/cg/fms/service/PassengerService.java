package com.cg.fms.service;

import java.util.List;

import com.cg.fms.dao.IPassengerDAO;
import com.cg.fms.dao.PassengerDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.PassengerNotFoundException;
import com.cg.fms.model.Passengers;

public class PassengerService implements IPassengerService{
	
	IPassengerDAO passengerDao = new PassengerDAO();
	/*********************************************************************
	 @Description : Method to enter all passenger details
	 @author : Sashwat Dubey
	 @arg1 : Passengers passenger
	 @return : int
	 @Exception : FMSException
	 */
	public int addPassengers(Passengers passenger) throws FMSException {
		return passengerDao.addPassengers(passenger);
	}
	
	/*********************************************************************
	 @Description : 
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean deletePassengers(int bookingId) throws PassengerNotFoundException, FMSException {
		return passengerDao.deletePassengers(bookingId);
	}
	
	/*********************************************************************
	 @Description : Method to change or update passenger details after booking
	 @author : Akshitha Gampa
	 @arg1 : Passengers passengers
	 @return : int
	 @Exception : FMSException
	 */
	public int modifyPassengers(Passengers passenger) throws PassengerNotFoundException,FMSException {
		return passengerDao.modifyPassengers(passenger);
	}
	
	/*********************************************************************
	 @Description : Method to view all passenger details based on booking
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : List<Passengers>
	 @Exception : FMSException
	 */
	public List<Passengers> viewPassengerDetails(int bookingId) throws PassengerNotFoundException,FMSException {
		return passengerDao.viewPassengerDetails(bookingId);
	}


}
