package com.cg.fms.service;

import java.util.List;

import com.cg.fms.exceptions.BookingNotFoundException;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;

public interface IBookingService {

	public List<Booking> viewBookings(int userId) throws BookingNotFoundException,FMSException;
	
	public int makeBooking(Booking booking) throws FMSException;
	
	public boolean cancelBooking(int bookingId) throws BookingNotFoundException,FMSException;

	public Booking viewBookingDetails(int bookingId) throws BookingNotFoundException,FMSException;
	
}
