package com.cg.fms.service;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.UserNotFoundException;
import com.cg.fms.model.User;

public interface IUserService {

	public boolean isUserExists(String emailId) throws UserNotFoundException, FMSException;

	public int accountCreation(User user) throws UserNotFoundException, FMSException;

	public int userLogin(String emailId, String password) throws UserNotFoundException, FMSException;

}
