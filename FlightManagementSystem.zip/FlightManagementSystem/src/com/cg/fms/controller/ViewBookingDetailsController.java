package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/ViewBookingDetailsController")
public class ViewBookingDetailsController extends HttpServlet {
	static Logger logger = Logger.getLogger(ViewBookingDetailsController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;
		IUserService service = new UserService();
		Booking booking = null;
		List<Passengers> passengers = null;
		ScheduleFlight scheduleFlight = null;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		try {
			booking = service.viewBookingDetails(bookingId);
			logger.debug("Value of booking in ViewBookingDetailsController:"+booking);
			passengers = service.viewPassengerDetails(bookingId);
			logger.debug("Value of passenger in ViewBookingDetailsController");
			scheduleFlight = service.viewFlightDetails(booking.getFlightNumber());
			if(booking != null && passengers.size() > 0 && scheduleFlight != null) {
				request.setAttribute("booking", booking);
				request.setAttribute("passengers", passengers);
				request.setAttribute("scheduleFlight", scheduleFlight);
				dispatcher = request.getRequestDispatcher("viewBookingDetails.jsp");
				dispatcher.forward(request, response);
				logger.info("Control is directed to viewBookingDetails.jsp");
				
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Problem occured while retrieving details! Try again');");
				out.println("location='userPage.jsp';");
				out.println("</script>");
				logger.info("Problem occurred while viewing the booking details");
			}
		} catch (FMSException e) {
			logger.error("Error while viewing the booking details");
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
