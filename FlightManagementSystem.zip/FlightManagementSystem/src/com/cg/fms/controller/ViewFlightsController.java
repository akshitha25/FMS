package com.cg.fms.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.Flight;
import com.cg.fms.service.FlightService;
import com.cg.fms.service.IFlightService;

import java.util.*;
/************************************************
@Description: Controller to view flights 
@Author: Tejaswi Paridi
************************************************/
@WebServlet("/ViewFlightsController")
public class ViewFlightsController extends HttpServlet{
	IFlightService service = new FlightService();
	RequestDispatcher dispatcher=null;
	static Logger logger = Logger.getLogger(ViewFlightsController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		HttpSession session = request.getSession();
		try {
			List<Flight> flights =  service.viewFlights();
			logger.debug("List of flights are:"+flights);
			if(flights.size() > 0) {
				request.setAttribute("flights",flights);
				dispatcher = request.getRequestDispatcher("viewFlights.jsp");
				dispatcher.forward(request,response);
				logger.info("Control is directed to viewFlights.jsp");
			} else {
				logger.info("Control is directed to adminPage.jsp to add flights");
				out.println("sorry flights are not added yet");
				dispatcher = request.getRequestDispatcher("adminPage.jsp");
				dispatcher.forward(request,response);
				
			}
		} catch (FMSException | FlightNotFoundException e) {
			logger.error("Problem occurred while viewing flights in ViewFlightsController:"+e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
		
		
	}
	

}
