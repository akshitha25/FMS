package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.Flight;
import com.cg.fms.service.FlightService;
import com.cg.fms.service.IFlightService;
/************************************************
@Description: Controller to add flights 
@Author: Paruchuri Sindhura
************************************************/
@WebServlet("/AddFlightController")
public class AddFlightController extends HttpServlet {
	int isCreated = 0;
	static Logger logger = Logger.getLogger(AddFlightController.class.getName());
	IFlightService service = new FlightService();

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String flightModel = request.getParameter("flightmodel");
		String carrierName = request.getParameter("carriername");
		int seatCapacity = Integer.parseInt(request.getParameter("seatcapacity"));
		Flight flight = new Flight(flightModel, carrierName, seatCapacity);
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		int flightNumber = 0;
		try {
			flightNumber = service.getFlightNumber(flightModel);
			if (flightNumber > 0) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Flight alraedy exists!! Please select another flight model');");
				out.println("location='addFlight.jsp';");
				out.println("</script>");
				logger.debug("flightNumber Value :" + flightNumber);
				logger.info("Flight is added successfully");

			} else {
				isCreated = service.addFlights(flight);
				if (isCreated > 0) {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Flight added successfully');");
					out.println("location='addFlight.jsp';");
					out.println("</script>");
					logger.debug("isCreated Value :" + isCreated);
					logger.info("Flight is added successfully");
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Problem occured while adding. Please try again!');");
					out.println("location='addFlight.jsp';");
					out.println("</script>");
					logger.info("Control Directed to addFlight.jsp if flights are not added");
				}
			}
		} catch (FMSException | FlightNotFoundException e) {
			logger.error("Error while adding the flights", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}

	}
}
