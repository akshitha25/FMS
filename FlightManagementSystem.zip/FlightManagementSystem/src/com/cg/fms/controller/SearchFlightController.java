package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.FlightService;
import com.cg.fms.service.IFlightService;
import com.cg.fms.service.IScheduleFlightService;
import com.cg.fms.service.ScheduleFlightService;
/************************************************
@Description: Controller to search a flight 
@Author: Tejaswi Paridi
************************************************/
@WebServlet("/SearchFlightController")
public class SearchFlightController extends HttpServlet {
	static Logger logger = Logger.getLogger(SearchFlightController.class.getName());
	IScheduleFlightService service = new ScheduleFlightService();
	IFlightService flightService = new FlightService();
	RequestDispatcher dispatcher = null;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		String flightModel = request.getParameter("flightNumber");

		try {

			int flightNumber = flightService.getFlightNumber(flightModel);

			if (flightNumber == 0) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Enter a valid flight number!');");
				out.println("location='adminPage.jsp';");
				out.println("</script>");
				logger.info("Entered flight number is not valid so it is again directed to searchFlight.jsp");

			} else {

				List<ScheduleFlight> scheduleFlight = service.searchFlight(flightNumber);
				logger.debug(scheduleFlight);
				if (scheduleFlight.size() > 0) {
					request.setAttribute("scheduleFlight", scheduleFlight);
					logger.info("Flight is searched based on entered flightnumber");
					dispatcher = request.getRequestDispatcher("searchFlight.jsp");
					dispatcher.forward(request, response);
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Enter a valid flight number!');");
					out.println("location='adminPage.jsp';");
					out.println("</script>");
					logger.info("Entered flight number is not valid so it is again directed to searchFlight.jsp");
				}
			}
		} catch (FMSException | FlightNotFoundException e) {
			logger.error("Error occurred while searching flights" + e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}

	}

}
