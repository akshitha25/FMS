package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;

@WebServlet("/SearchFlightController")
public class SearchFlightController extends HttpServlet {
	static Logger logger = Logger.getLogger(SearchFlightController.class.getName());
	IAdminService service = new AdminService();
	RequestDispatcher dispatcher=null;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		HttpSession session = request.getSession();
		int flightNumber = Integer.parseInt(request.getParameter("flightNumber"));
		
		
		if(flightNumber == 0 ) {
			out.println("please enter correct value");
			logger.info("Please enter correct value");
			logger.info("Control is directed to searchFlight.jsp");
			dispatcher = request.getRequestDispatcher("searchFlight.jsp");
			dispatcher.include(request, response);
		
		} else {

	
		try {
			List<ScheduleFlight> scheduleFlight =  service.searchFlight(flightNumber);
			logger.debug(scheduleFlight);
			if(scheduleFlight.size() > 0) {
				request.setAttribute("scheduleFlight",scheduleFlight);
				logger.info("Flight is searched based on entered flightnumber");
				dispatcher = request.getRequestDispatcher("searchFlight.jsp");
				dispatcher.forward(request,response);
			} else {
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Enter a valid flight number!');");
				   out.println("location='adminPage.jsp';");
				   out.println("</script>");	
				   logger.info("Entered flight number is not valid so it is again directed to searchFlight.jsp" );
			}
		} catch (FMSException e) {
			logger.error("Error occurred while searching flights"+e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
		
		
	}
	}

}

