package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IScheduleFlightService;
import com.cg.fms.service.ScheduleFlightService;
/************************************************
@Description: Controller to view scheduled flights 
@Author: Paruchuri Sindhura, Tejaswi Paridi
************************************************/
@WebServlet("/ViewScheduleFlightController")
public class ViewScheduleFlightController extends HttpServlet{
	IScheduleFlightService service = new ScheduleFlightService();
	RequestDispatcher dispatcher=null;
	static Logger logger = Logger.getLogger(ViewScheduleFlightController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		HttpSession session = request.getSession();
		try {
			List<ScheduleFlight> scheduleFlights =  service.viewScheduleFlights();
			logger.debug("List of schedule flights are:"+scheduleFlights);
			if(scheduleFlights.size() > 0) {
				request.setAttribute("scheduleFlights",scheduleFlights);
				dispatcher = request.getRequestDispatcher("viewScheduleFlight.jsp");
				dispatcher.forward(request,response);
				logger.info("Control is forwarded to viewScheduleFlight.jsp");
			} else {
				out.println("sorry flights are not added yet");
				dispatcher = request.getRequestDispatcher("adminPage.jsp");
				dispatcher.forward(request,response);
				logger.info("flights are not added yet so you cannot schedule them");
				logger.info("Control is directed to adminPage.jsp");
				
			}
		} catch (FMSException | FlightNotFoundException e) {
			logger.error("Problem occurred in ViewScheduleFlightController");
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
		
		
	}
}
