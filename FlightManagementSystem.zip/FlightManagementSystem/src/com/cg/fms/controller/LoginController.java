package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	static Logger logger = Logger.getLogger(LoginController.class.getName());
	IUserService userService = new UserService();
	int isLogged =0;
	IAdminService adminService = new AdminService();
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws  IOException, ServletException {
	String emailId = request.getParameter("uemail");
	String password = request.getParameter("upass");
	PrintWriter out = response.getWriter();
	RequestDispatcher dispatcher =null;
	ServletContext context = request.getServletContext();
	HttpSession session = request.getSession();
	session.setAttribute("emailId", emailId);
	try {
		if(emailId.equals("admin@gmail.com") && password.equals("Admin24!")) {
			isLogged = adminService.adminLogin(emailId, password);
			dispatcher = request.getRequestDispatcher("adminPage.jsp");
			dispatcher.forward(request, response);
			logger.debug("Value after login for admin:"+isLogged);
			logger.info("Control directed to adminPage.jsp");

		}
		else {
			isLogged = userService.userLogin(emailId,password);
			context.setAttribute("userId", isLogged);
		if(isLogged == 0) {
			if(userService.isUserExists(emailId)) {
				logger.info("User entered invalid credentials");
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Please enter the correct password!');");
				   out.println("location='Login.jsp';");
				   out.println("</script>");
			} else {
				logger.info("User doesnot exists");
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('User doesnot exist. Please register!');");
				   out.println("location='Register.jsp';");
				   out.println("</script>");
			}
		} else {
			logger.info("Logged in successfully");
			   out.println("<script type=\"text/javascript\">");
			   out.println("alert('Logged in successfully');");
			   out.println("location='userPage.jsp';");
			   out.println("</script>");
		}
		}
			
	} catch (FMSException e) {
		logger.error("Error while logging into application", e);
		session.setAttribute("errorMessage", e.getMessage());
		response.sendRedirect("errorPage.jsp");
	}		
	
}
}
