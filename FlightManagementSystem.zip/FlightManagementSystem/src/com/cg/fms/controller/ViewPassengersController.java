package com.cg.fms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.PassengerNotFoundException;
import com.cg.fms.model.Passengers;
import com.cg.fms.service.IPassengerService;
import com.cg.fms.service.PassengerService;

/************************************************
@Description: Controller to view passengers 
@Author: Akshitha Gampa
************************************************/
@WebServlet("/ViewPassengersController")
public class ViewPassengersController extends HttpServlet{
	static Logger logger = Logger.getLogger(ViewPassengersController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IPassengerService service = new PassengerService();
		HttpSession session = request.getSession();
		List<Passengers> passengers = null;
		RequestDispatcher dispatcher = null;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		try {
			passengers = service.viewPassengerDetails(bookingId);
			logger.debug("Value of passengers in ViewPassengersController:"+passengers);
			request.setAttribute("passengers", passengers);
			dispatcher = request.getRequestDispatcher("viewPassengerDetails.jsp");
			dispatcher.forward(request, response);
			logger.info("Control is directed to viewPassengerDetails.jsp");
		}  catch (FMSException | PassengerNotFoundException e) {
			 logger.error("Error while viewing passenger details", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
}
