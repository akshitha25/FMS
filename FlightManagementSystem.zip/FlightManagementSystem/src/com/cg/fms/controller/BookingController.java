package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;

import com.cg.fms.model.Passengers;
import com.cg.fms.service.IPassengerService;
import com.cg.fms.service.PassengerService;
/************************************************
@Description: Controller to book flights 
@Author: Sashwat Dubey
************************************************/
@WebServlet("/BookingController")
public class BookingController extends HttpServlet {
	static Logger logger = Logger.getLogger(BookingController.class.getName());
	static int passengerCount = 0;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IPassengerService service = new PassengerService();
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		Passengers passenger = null;
		HttpSession session = request.getSession();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String bookingDate = timestamp.toString();
		ServletContext context = request.getServletContext();
		int userId = Integer.parseInt("" + context.getAttribute("userId"));
		int bookingId = Integer.parseInt("" + context.getAttribute("bookingId"));
		int passengers = Integer.parseInt("" + context.getAttribute("passengerCount"));
		try {
			int addPassenger = 0;
			String passengerName = request.getParameter("name");
			int passengerAge = Integer.parseInt(request.getParameter("age"));
			String passengerGender = request.getParameter("gender");
			double passengerLuggage = Double.parseDouble(request.getParameter("luggage"));
			long passengerAadhar = Long.parseLong(request.getParameter("aadhar"));
			passenger = new Passengers(passengerName, passengerAge, passengerAadhar, passengerLuggage, passengerGender,
					userId, bookingDate, bookingId);
			addPassenger = service.addPassengers(passenger);
			logger.debug("Value of addPassenger:" + addPassenger);
			if (addPassenger > 0) {
				passengerCount++;
			}
			if (request.getParameter("addPassengers") != null && passengerCount < passengers) {
				dispatcher = request.getRequestDispatcher("passengers.jsp");
				dispatcher.include(request, response);
				logger.info("Control is directed to passengers.jsp");
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Your flight has been booked successfully!');");
				out.println("location='userPage.jsp';");
				out.println("</script>");
				logger.info("Flight is successfully booked");
				logger.info("Control is directed to userPage.jsp after booking flights is done");
			}
		} catch (FMSException e) {
			logger.error("Error while booking the flights", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}
