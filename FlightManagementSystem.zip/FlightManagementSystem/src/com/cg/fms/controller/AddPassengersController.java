package com.cg.fms.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.BookingService;
import com.cg.fms.service.IBookingService;
import com.cg.fms.service.IScheduleFlightService;
import com.cg.fms.service.ScheduleFlightService;
/************************************************
@Description: Controller to add passengers 
@Author: Sashwat Dubey
************************************************/
@WebServlet("/AddPassengersController")
public class AddPassengersController extends HttpServlet {
	static Logger logger = Logger.getLogger(AddPassengersController.class.getName());

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IBookingService bookingService = new BookingService();
		IScheduleFlightService flightService = new ScheduleFlightService();
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		int passengerCount = Integer.parseInt(request.getParameter("passengerCount"));
		ServletContext context = request.getServletContext();
		int flightNumber = (int) session.getAttribute("flightNumber");
		int userId = Integer.parseInt("" + context.getAttribute("userId"));
		LocalDate now = LocalDate.now();
		String bookingDate = now.toString();
		Booking booking = null;
		ScheduleFlight flight = null;
		int availableSeats = 0;
		double cost = 0;
		int makeBooking = 0;
		int isUpdated = 0;
		try {
			flight = flightService.viewFlightDetails(flightNumber);
			cost = (passengerCount) * flight.getCost();
			booking = new Booking(userId, bookingDate, cost, passengerCount, "booked", flightNumber);
			logger.debug(booking);
			makeBooking = bookingService.makeBooking(booking);
			context.setAttribute("bookingId", makeBooking);
			context.setAttribute("passengerCount", passengerCount);
			if (makeBooking > 0) {
				logger.debug("Make Booking Value:" + makeBooking);
				availableSeats = flight.getAvailableSeats();
				availableSeats -= (passengerCount);
				isUpdated = flightService.updateAvailableSeats(availableSeats, flightNumber);
				dispatcher = request.getRequestDispatcher("passengers.jsp");
				dispatcher.include(request, response);
				logger.debug("UpdatedSeats after booking:" + isUpdated);
				logger.info("Control is directed to passengers.jsp");
			}

		} catch (FMSException | FlightNotFoundException e) {
			logger.error("Error while adding the passengers", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}
