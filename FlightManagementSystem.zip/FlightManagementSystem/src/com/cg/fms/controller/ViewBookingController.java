package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.BookingNotFoundException;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.service.BookingService;
import com.cg.fms.service.IBookingService;
/************************************************
@Description: Controller to view bookings 
@Author: Akshitha Gampa
************************************************/
@WebServlet("/ViewBookingController")
public class ViewBookingController extends HttpServlet {
	static Logger logger = Logger.getLogger(ViewBookingController.class.getName());

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IBookingService bookingService = new BookingService();
		List<Booking> bookings = null;
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		ServletContext context = request.getServletContext();
		int userId = Integer.parseInt("" + context.getAttribute("userId"));
		try {
			bookings = bookingService.viewBookings(userId);
			logger.debug(bookings);
			if (bookings.size() > 0) {
				request.setAttribute("bookings", bookings);
				dispatcher = request.getRequestDispatcher("viewBookings.jsp");
				dispatcher.forward(request, response);
				logger.info("Control is directed to viewBookings.jsp");
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Sorry, you have not made any bookings yet!');");
				out.println("location='userPage.jsp';");
				out.println("</script>");
				logger.info("Bookings are not made yet so you cannot view them");
			}

		} catch (FMSException | BookingNotFoundException e) {
			logger.error("Error while viewing bookings made", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}

	}

}
