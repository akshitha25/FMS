package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.PassengerNotFoundException;
import com.cg.fms.model.Passengers;
import com.cg.fms.utility.JdbcUtility;

public class PassengerDAO implements IPassengerDAO{

	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;
	
	/*********************************************************************
	 @Description : Method to enter all passenger details
	 @author : Sashwat Dubey
	 @arg1 : Passengers passenger
	 @return : int
	 @Exception : FMSException
	 */
	public int addPassengers(Passengers passenger) throws FMSException {
		int isInserted = 0;
		if(passenger != null) {
			try {
			  connection = JdbcUtility.getConnection();
			  prepareStatement = connection.prepareStatement(PassengerQueryConstants.ADD_PASSENGER, Statement.RETURN_GENERATED_KEYS );
			  prepareStatement.setString(1,passenger.getPassengerName());
			  prepareStatement.setInt(2,passenger.getPassengerAge() );
			  prepareStatement.setLong(3,passenger.getPassengerUIN() );
			  prepareStatement.setDouble(4,passenger.getLuggage());
			  prepareStatement.setInt(5,passenger.getUserId() );
			  prepareStatement.setString(6,passenger.getPassengerGender());
			  prepareStatement.setString(7, passenger.getBookingDate());
			  prepareStatement.setInt(8,passenger.getBookingId() );
			  prepareStatement.executeUpdate();
			  resultSet = prepareStatement.getGeneratedKeys();
			while(resultSet.next()) {
				isInserted = resultSet.getInt(1);
			}
			} catch (SQLException | ClassNotFoundException exception) {
				throw new FMSException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FMSException(exception.getMessage());
				}
	
			}
		}
		return isInserted;
	}
	
	
	/*********************************************************************
	 @Description : 
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean deletePassengers(int bookingId) throws PassengerNotFoundException,FMSException {
		boolean isDeleted = false;
		int rowUpdate = 0;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(PassengerQueryConstants.DELETE_PASSENGERS);
			prepareStatement.setInt(1, bookingId);
			rowUpdate = prepareStatement.executeUpdate();
			if(rowUpdate > 0) {
				isDeleted = true;
			}
		}
		catch(SQLException exception) {
			throw new PassengerNotFoundException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new PassengerNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new PassengerNotFoundException(exception.getMessage());
			}

		}	
		return isDeleted;
	}
	
	/*********************************************************************
	 @Description : Method to change or update passenger details after booking
	 @author : Akshitha Gampa
	 @arg1 : Passengers passengers
	 @return : int
	 @Exception : FMSException
	 */
	public int modifyPassengers(Passengers passengers) throws PassengerNotFoundException,FMSException {
		int isModify = 0;
		if(passengers != null) {
			try {
				connection = JdbcUtility.getConnection();
				prepareStatement = connection.prepareStatement(PassengerQueryConstants.UPDATE_PASSENGER);
				prepareStatement.setString(1, passengers.getPassengerName());
				prepareStatement.setInt(2, passengers.getPassengerAge());
				prepareStatement.setLong(3, passengers.getPassengerUIN());
				prepareStatement.setDouble(4, passengers.getLuggage());
				prepareStatement.setString(5, passengers.getPassengerGender());
				prepareStatement.setInt(6, passengers.getPnrNumber());
				isModify = prepareStatement.executeUpdate();
				
			}
			catch(SQLException exception) {
				throw new PassengerNotFoundException(exception.getMessage());
			} catch(ClassNotFoundException exception) {
				throw new PassengerNotFoundException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new PassengerNotFoundException(exception.getMessage());
				}
				
			}
		}
		
		return isModify;
	}
	
	/*********************************************************************
	 @Description : Method to view all passenger details based on booking
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : List<Passengers>
	 @Exception : FMSException
	 */
	public List<Passengers> viewPassengerDetails(int bookingId) throws PassengerNotFoundException,FMSException {
		List<Passengers> passengers = new ArrayList<Passengers>();
		Passengers passenger  = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(PassengerQueryConstants.VIEW_PASSENGER_DETAILS);
			prepareStatement.setInt(1, bookingId);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				passenger= new Passengers();
				passenger.setPnrNumber(resultSet.getInt(1));
				passenger.setPassengerName(resultSet.getString(2));
				passenger.setPassengerAge(resultSet.getInt(3));
				passenger.setPassengerUIN(resultSet.getLong(4));
				passenger.setLuggage(resultSet.getDouble(5));
				passenger.setUserId(resultSet.getInt(6));
				passenger.setPassengerGender(resultSet.getString(7));
				passenger.setBookingDate(resultSet.getString(8));
				passenger.setBookingId(resultSet.getInt(9));
				passengers.add(passenger);
			}
		
		} catch(SQLException exception) {
			throw new PassengerNotFoundException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new PassengerNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new PassengerNotFoundException(exception.getMessage());
			}

		}
		return passengers;
	}
	
	
}
