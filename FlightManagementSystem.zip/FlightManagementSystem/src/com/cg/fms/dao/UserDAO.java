package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.UserNotFoundException;
import com.cg.fms.model.User;
import com.cg.fms.utility.JdbcUtility;

public class UserDAO implements IUserDAO{

	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;
	
	
	/*********************************************************************
	 @Description : Method to check whether the entered user exists or not
	 @author : Bhavana Teja
	 @arg1 : String emailId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean isUserExists(String emailId) throws UserNotFoundException, FMSException{
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(UserQueryConstants.USER_EXISTS);
			prepareStatement.setString(1, emailId);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
			}
		} catch (SQLException exception) {
			throw new UserNotFoundException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new UserNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new UserNotFoundException(exception.getMessage());
			}

		}
        return found;
	}
	
	
	/*********************************************************************
	 @Description : Method for the user to create his account
	 @author : Bhavana Teja
	 @arg1 : User user
	 @return : int
	 @Exception : FMSException
	 */
	public int accountCreation(User user) throws UserNotFoundException, FMSException {
		int isInserted = 0;
			if(user != null && !(isUserExists(user.getEmailId()))) {
				try {
				  connection = JdbcUtility.getConnection();
				  prepareStatement = connection.prepareStatement(UserQueryConstants.REGISTER_USER, Statement.RETURN_GENERATED_KEYS );
				  prepareStatement.setString(1,user.getUserName());
				  prepareStatement.setString(2,user.getPassword() );
				  prepareStatement.setLong(3,user.getMobileNumber() );
				  prepareStatement.setString(4,user.getEmailId() );
				  prepareStatement.executeUpdate();
				  resultSet = prepareStatement.getGeneratedKeys();
				while(resultSet.next()) {
					isInserted = resultSet.getInt(1);
				}
				} catch (SQLException | ClassNotFoundException exception) {
					throw new UserNotFoundException(exception.getMessage());
				} finally {
					try {
						connection.close();
					} catch (SQLException exception) {
						throw new UserNotFoundException(exception.getMessage());
					}

				}
			}
			return isInserted;
	}
	
	
	/*********************************************************************
	 @Description : Method for user to login into the application
	 @author : Bhavana Teja
	 @arg1 : String emailId
	 @arg2 : String password
	 @return : int 
	 @Exception : FMSException
	 */
	public int userLogin(String emailId, String password) throws UserNotFoundException, FMSException {
		
		int rows =0;
		try {
				connection = JdbcUtility.getConnection();
				prepareStatement = connection.prepareStatement(UserQueryConstants.USER_LOGIN);
				prepareStatement.setString(1, emailId);
				prepareStatement.setString(2, password);
				resultSet = prepareStatement.executeQuery();
				if(resultSet.next()) {
					rows = resultSet.getInt(1);
					
				}
			}
			catch(ClassNotFoundException exception) {
				throw new UserNotFoundException(exception.getMessage());
			}
			catch(SQLException exception) {
				throw new UserNotFoundException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new UserNotFoundException(exception.getMessage());
				}

			}
			return rows;
	}
	
	
	
	
	
}
