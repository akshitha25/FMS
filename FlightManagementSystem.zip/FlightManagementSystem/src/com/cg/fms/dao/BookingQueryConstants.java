package com.cg.fms.dao;

public interface BookingQueryConstants {

	String MAKE_BOOKING = "insert into booking(userid,booking_date,cost,passenger_count,booking_state,flight_number)values(?,?,?,?,?,?)";
	String VIEW_BOOKINGS = "select * from booking where userid = ?";
	String CANCEL_BOOKING = "delete from booking where booking_id=?";
	String VIEW_BOOKING_DETAILS="select * from booking where booking_id=?";
	
	
}
