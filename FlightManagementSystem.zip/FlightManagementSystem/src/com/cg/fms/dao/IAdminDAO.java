package com.cg.fms.dao;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import java.util.*;


public interface IAdminDAO {
	
	public int adminLogin(String emailId, String password) throws FMSException;

	public List<Airport> viewAirports() throws FMSException;
	
}
