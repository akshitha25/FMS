package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.Flight;
import com.cg.fms.utility.JdbcUtility;

public class FlightDAO implements IFlightDAO {

	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	static ResultSet resultSet = null;

	/************************************************
	 * @Description: Method to add flights
	 * @Author: Paruchuri Sindhura
	 * @arg1: Flight flight
	 * @returns: int
	 * @Exception: FMSException
	 ************************************************/

	public int addFlights(Flight flight) throws FlightNotFoundException, FMSException {
		int rows = 0;
		if (flight != null && getFlightDetails(flight.getFlightModel()) == 0) {
			try {
				connection = JdbcUtility.getConnection();
				preparedStatement = connection.prepareStatement(FlightQueryConstants.ADD_FLIGHT,
						Statement.RETURN_GENERATED_KEYS);
				preparedStatement.setString(1, flight.getFlightModel());
				preparedStatement.setString(2, flight.getCarrierName());
				preparedStatement.setInt(3, flight.getSeatCapacity());
				preparedStatement.executeUpdate();
				resultSet = preparedStatement.getGeneratedKeys();
				while (resultSet.next()) {
					rows = resultSet.getInt(1);
				}
			} catch (SQLException exception) {
				throw new FlightNotFoundException(exception.getMessage());
			} catch (ClassNotFoundException exception) {
				throw new FlightNotFoundException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FlightNotFoundException(exception.getMessage());
				}

			}
		}
		return rows;
	}

	/************************************************
	 * @Description: Method to view flights
	 * @Author: Tejaswi Paridi
	 * @returns: List flight
	 * @Exception: FMSException
	 ************************************************/
	public List<Flight> viewFlights() throws FlightNotFoundException, FMSException {
		List<Flight> list = new ArrayList<Flight>();
		Flight flight = null;

		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(FlightQueryConstants.VIEW_FLIGHTS);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				flight = new Flight();
				flight.setFlightNumber(resultSet.getInt(1));
				flight.setFlightModel(resultSet.getString(2));
				flight.setCarrierName(resultSet.getString(3));
				flight.setSeatCapacity(resultSet.getInt(4));
				list.add(flight);
			}

		} catch (SQLException exception) {
			throw new FlightNotFoundException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FlightNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FlightNotFoundException(exception.getMessage());
			}

		}
		return list;
	}

	/************************************************************
	 * @Description: Method to get flight details
	 * @Author: Paruchuri Sindhura
	 * @arg1: String flightModel
	 * @returns: int
	 * @Exception: FMSException
	 *************************************************************/
	public int getFlightDetails(String flightModel) throws FlightNotFoundException, FMSException {
		int flightNumber = 0;
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(FlightQueryConstants.GET_FLIGHT);
			preparedStatement.setString(1, flightModel);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flightNumber = resultSet.getInt(1);
			}
		} catch (SQLException exception) {
			throw new FlightNotFoundException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FlightNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FlightNotFoundException(exception.getMessage());
			}

		}
		return flightNumber;
	}

}
