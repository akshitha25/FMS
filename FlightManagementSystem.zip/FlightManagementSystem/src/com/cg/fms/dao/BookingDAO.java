package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.BookingNotFoundException;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.utility.JdbcUtility;

public class BookingDAO implements IBookingDAO{
	
	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;

	/*********************************************************************
	 @Description : Method to book a flight
	 @author : Sashwat Dubey
	 @arg1 : Booking booking
	 @return : int
	 @Exception : FMSException
	 */
	public int makeBooking(Booking booking) throws FMSException {
		int isInserted = 0;
		if(booking != null) {
			try {
			  connection = JdbcUtility.getConnection();
			  prepareStatement = connection.prepareStatement(BookingQueryConstants.MAKE_BOOKING, Statement.RETURN_GENERATED_KEYS );
			  prepareStatement.setInt(1,booking.getUserId());
			  prepareStatement.setString(2,booking.getBookingDate() );
			  prepareStatement.setDouble(3,booking.getCost());
			  prepareStatement.setDouble(4,booking.getPassengerCount());
			  prepareStatement.setString(5,booking.getBookingState() );
			  prepareStatement.setInt(6,booking.getFlightNumber());
			  prepareStatement.executeUpdate();
			  resultSet = prepareStatement.getGeneratedKeys();
			while(resultSet.next()) {
				isInserted = resultSet.getInt(1);
			}
			} catch (SQLException | ClassNotFoundException exception) {
				throw new FMSException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FMSException(exception.getMessage());
				}
	
			}
		}
		return isInserted;
	}
	
	
	/*********************************************************************
	 @Description : Method to cancel booking made by customer
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean cancelBooking(int bookingId) throws BookingNotFoundException,FMSException {
		boolean isCancelled = false;
		int rowUpdate = 0;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(BookingQueryConstants.CANCEL_BOOKING);
			prepareStatement.setInt(1, bookingId);
			rowUpdate= prepareStatement.executeUpdate();
			if(rowUpdate>0) {
				isCancelled = true;
			}
		}
		catch(SQLException exception) {
			throw new BookingNotFoundException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new BookingNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new BookingNotFoundException(exception.getMessage());
			}

		}	
		return isCancelled;
	}

	
	/*********************************************************************
	 @Description : Method to view all the bookings made by the customer
	 @author : Akshitha Gampa
	 @arg1 : int userId
	 @return : List<Booking>
	 @Exception : FMSException
	 */
	public List<Booking> viewBookings(int userId) throws BookingNotFoundException,FMSException {
		List<Booking> bookings = new ArrayList<Booking>();
		Booking booking  = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(BookingQueryConstants.VIEW_BOOKINGS);
			prepareStatement.setInt(1, userId);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				booking= new Booking();
				booking.setBookingId(resultSet.getInt(1));
				booking.setUserId(resultSet.getInt(2));
				booking.setBookingDate(resultSet.getString(3));
				booking.setCost(resultSet.getDouble(4));
				booking.setPassengerCount(resultSet.getInt(5));
				booking.setBookingState(resultSet.getString(6));
				booking.setFlightNumber(resultSet.getInt(7));
				bookings.add(booking);
			}
		
		} catch(SQLException exception) {
			throw new BookingNotFoundException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new BookingNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new BookingNotFoundException(exception.getMessage());
			}

		}
		return bookings;
	}
	
	
	
	
	
	/*********************************************************************
	 @Description : Method to view all booking details after booking is done
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : Booking
	 @Exception :  FMSException 
	 */
	public Booking viewBookingDetails(int bookingId) throws BookingNotFoundException,FMSException {
		Booking booking  = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(BookingQueryConstants.VIEW_BOOKING_DETAILS);
			prepareStatement.setInt(1, bookingId);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				booking= new Booking();
				booking.setBookingId(resultSet.getInt(1));
				booking.setUserId(resultSet.getInt(2));
				booking.setBookingDate(resultSet.getString(3));
				booking.setCost(resultSet.getDouble(4));
				booking.setPassengerCount(resultSet.getInt(5));
				booking.setBookingState(resultSet.getString(6));
				booking.setFlightNumber(resultSet.getInt(7));
			
				
			}
		
		} catch(SQLException exception) {
			throw new BookingNotFoundException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new BookingNotFoundException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new BookingNotFoundException(exception.getMessage());
			}

		}
		return booking;
	}
	
	
	
}
