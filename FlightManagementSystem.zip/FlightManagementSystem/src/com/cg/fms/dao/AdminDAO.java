package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.model.Flight;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.utility.JdbcUtility;

public class AdminDAO implements IAdminDAO {
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	static ResultSet resultSet = null;
	
	
	/************************************************
	 @Description: Admin Login
	 @Author: Bhavana Teja
	 @arg1: String emailId
	 @arg2: String password
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	
	public int adminLogin(String emailId, String password) throws FMSException {
		int rows =0;
		try {
				connection = JdbcUtility.getConnection();
				preparedStatement = connection.prepareStatement(AdminQueryConstants.ADMIN_LOGIN);
				preparedStatement.setString(1, emailId);
				preparedStatement.setString(2, password);
				resultSet = preparedStatement.executeQuery();
				while(resultSet.next()) {
					rows = resultSet.getInt(1);
					
				}
			}
			catch(ClassNotFoundException exception) {
				throw new FMSException(exception.getMessage());
			}
			catch(SQLException exception) {
				throw new FMSException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FMSException(exception.getMessage());
				}

			}
			return rows;
	}
	
	/************************************************
	 @Description: Method to add flights
	 @Author: Paruchuri Sindhura
	 @arg1: Flight flight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	
	public  int addFlights(Flight flight) throws FMSException {
		int rows =0;
		
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(AdminQueryConstants.ADD_FLIGHT,Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, flight.getFlightModel());
			preparedStatement.setString(2, flight.getCarrierName());
			preparedStatement.setInt(3, flight.getSeatCapacity());
			preparedStatement.executeUpdate();
			resultSet =preparedStatement.getGeneratedKeys();
			while(resultSet.next()){
				rows = resultSet.getInt(1);
			}
		} catch (SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}
	
		}
		return rows;
	}
	
	/************************************************
	 @Description: Method to view flights
	 @Author: Tejaswi Paridi
	 @returns: List flight
	 @Exception: FMSException
	 ************************************************/
	public List<Flight> viewFlights() throws FMSException {
		List<Flight> list = new ArrayList<Flight>();
		Flight flight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(AdminQueryConstants.VIEW_FLIGHTS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
	        	flight = new Flight();
	        	flight.setFlightNumber(resultSet.getInt(1));
	        	flight.setFlightModel(resultSet.getString(2));
	        	flight.setCarrierName(resultSet.getString(3));
	        	flight.setSeatCapacity(resultSet.getInt(4));
	        	list.add(flight);
			}
		
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		return list;
	}
	
	/************************************************
	 @Description: Method to view all airports
	 @Author: Paruchuri Sindhura, Tejaswi Paridi
	 @returns: List airports
	 @Exception: FMSException
	 ************************************************/
	public List<Airport> viewAirports() throws FMSException {
		List<Airport> airports = new ArrayList<Airport>();
		Airport airport = null;
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(AdminQueryConstants.VIEW_AIRPORTS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				airport = new Airport();
				airport.setAirportCode(resultSet.getString(1));
				airport.setAirportName(resultSet.getString(2));
				airport.setAirportLocation(resultSet.getString(3));
				airports.add(airport);
			}
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		
		return airports;
		
	}
	
	/************************************************
	 @Description: Method to schedule flights
	 @Author: Paruchuri Sindhura
	 @arg1: ScheduleFlight scheduleFlight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int scheduleFlight(ScheduleFlight scheduleFlight) throws FMSException {
		int rows =0;
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(AdminQueryConstants.SCHEDULE_FLIGHT);
			preparedStatement.setInt(1, scheduleFlight.getFlightNumber());
			preparedStatement.setInt(2, scheduleFlight.getAvailableSeats());
			preparedStatement.setDouble(3, scheduleFlight.getCost());
			preparedStatement.setString(4, scheduleFlight.getSourceAirport());
			preparedStatement.setString(5, scheduleFlight.getDestinationAirport());
			preparedStatement.setString(10, scheduleFlight.getFlightStatus());
			preparedStatement.setDate(6, new Date(scheduleFlight.getDepartureDate().getTime()));
			preparedStatement.setDate(7, new Date(scheduleFlight.getArrivalDate().getTime()));
			preparedStatement.setString(8, scheduleFlight.getArrivalTime());
			preparedStatement.setString(9, scheduleFlight.getDepartureTime());
			rows = preparedStatement.executeUpdate();
		} catch (SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}
	
		}
		return rows;
	}
	
	/*****************************************************
	 @Description: method to view all the scheduled flights
	 @Author: Paruchuri Sindhura, Tejaswi Paridi
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 *****************************************************/
	public List<ScheduleFlight> viewScheduleFlights() throws FMSException {
		List<ScheduleFlight> scheduleFlights = new ArrayList<ScheduleFlight>();
		ScheduleFlight scheduleFlight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(AdminQueryConstants.VIEW_SCHEDULE_FLIGHTS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				scheduleFlights.add(scheduleFlight);
			}
		
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		return scheduleFlights;
	}

	/********************************************************
	 @Description: Method to search flights by flight number
	 @Author: Tejaswi Paridi
	 @arg1: int flightNumber
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 ********************************************************/
	public List<ScheduleFlight> searchFlight(int flightNumber) throws FMSException {
		List<ScheduleFlight> scheduleFlights = new ArrayList<ScheduleFlight>();
		ScheduleFlight scheduleFlight = null;

		try {
			connection = JdbcUtility.getConnection();

			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(AdminQueryConstants.SEARCH_FLIGHT);
			preparedStatement.setInt(1, flightNumber);

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				scheduleFlights.add(scheduleFlight);
			}

		} catch (SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		} 
		return scheduleFlights;
	}
}
