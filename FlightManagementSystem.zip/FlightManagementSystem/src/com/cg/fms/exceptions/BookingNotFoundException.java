package com.cg.fms.exceptions;

public class BookingNotFoundException extends Exception {
	
	public BookingNotFoundException(String message){
		super(message);
	}

}
