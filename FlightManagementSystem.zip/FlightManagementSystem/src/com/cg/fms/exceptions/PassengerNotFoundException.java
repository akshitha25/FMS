package com.cg.fms.exceptions;

public class PassengerNotFoundException extends Exception {
	
	public PassengerNotFoundException(String message){
		super(message);
	}

}
