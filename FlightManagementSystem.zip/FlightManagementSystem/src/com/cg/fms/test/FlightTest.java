package com.cg.fms.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.model.Flight;
import com.cg.fms.service.FlightService;
import com.cg.fms.service.IFlightService;

public class FlightTest {
	
	IFlightService service = new FlightService();
	@Test
	public void addFlightTest() throws FlightNotFoundException, FMSException {
	
	Flight flight1 = new Flight("ZX34BV678", "AirIndia", 250);
	int result1 = service.addFlights(flight1);
	boolean actualResult1;
	boolean expectedResult1;
	if(result1 > 0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1, actualResult1);
	
	Flight flight2 = null;
	int result2 = service.addFlights(flight2);
	boolean actualResult2;
	boolean expectedResult2;
	if(result2 > 0) {
	actualResult2 = true;
	} else {
	actualResult2 = false;
	}
	expectedResult2 = false;
	assertEquals(expectedResult2, actualResult2);
	
	}
	
	@Test
	public void viewFlightsTest() throws FlightNotFoundException, FMSException {
	
	List<Flight> result1= service.viewFlights();
	boolean actualResult1;
	boolean expectedResult1;
	if(result1.size() !=0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1,actualResult1);
	
	
	}
}
