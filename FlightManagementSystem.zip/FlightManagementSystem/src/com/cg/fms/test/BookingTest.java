package com.cg.fms.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.cg.fms.exceptions.BookingNotFoundException;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.service.BookingService;
import com.cg.fms.service.IBookingService;

public class BookingTest {

	IBookingService bookingService = new BookingService();
	@Test
	public void makeBookingTest() throws FMSException {
	 Booking booking1 = new Booking(118,"2020-10-21",2400,2,"booked",12);
	 int result1= bookingService.makeBooking(booking1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1); 
		
		Booking booking2 = null;
		 int result2= bookingService.makeBooking(booking2);
			boolean actualResult2;
			boolean expectedResult2;
			if(result2 > 0) {
				actualResult2 = true;
			} else {
				actualResult2 = false;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2); 
	
	}
	
	
	@Test
	public void viewBookings() throws FMSException, BookingNotFoundException {
		int userId1 = 116;
		int userId2 = 0;
		List<Booking> result1= bookingService.viewBookings(userId1);
		 boolean actualResult1;
			boolean expectedResult1;
			if(result1.size() !=0) {
				actualResult1 = true;
			} else {
				actualResult1 = false;
			}
			expectedResult1 = true;
			assertEquals(expectedResult1,actualResult1);
			
			
			
			List<Booking> result2= bookingService.viewBookings(userId2);
			boolean actualResult2;
			boolean expectedResult2;
			if( result2.size()!= 0) {
				actualResult2 = true;
			} else {
				actualResult2 = false;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2);
	}
	
	@Test
	public void cancelBookingTest() throws FMSException, BookingNotFoundException {
		boolean result1= bookingService.cancelBooking(117);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 == true) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		
		boolean result2= bookingService.cancelBooking(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 == true) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2); 
		
	}
	
	
	@Test
	public void viewBookingDetailsTest() throws FMSException, BookingNotFoundException {
		Booking result1= bookingService.viewBookingDetails(116);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 != null) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		
		Booking result2= bookingService.viewBookingDetails(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 != null) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
	
	}
	
	
	
}
